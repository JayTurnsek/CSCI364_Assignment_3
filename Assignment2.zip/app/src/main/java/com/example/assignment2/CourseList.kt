package com.example.assignment2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment2.adapter.CourseAdapter
import com.example.assignment2.data.Datasource
import com.example.assignment2.model.Course
import com.google.android.material.snackbar.Snackbar
import java.io.Serializable

class CourseList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_list)

        actionBar?.setDisplayHomeAsUpEnabled(true)

        // Init required variables
        val courseDataset = Datasource().loadData()
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        val selectedCourses = ArrayList<Course>()

        // Set up recyclerView of courses
        recyclerView.adapter = CourseAdapter(this, courseDataset, selectedCourses)
        recyclerView.setHasFixedSize(true)

        // Get selected Courses
        val selected = (recyclerView.adapter as CourseAdapter).getSelectedCourses()

        val submitButton: Button = findViewById(R.id.submit_button)
        submitButton.setOnClickListener {
            when (handleCourses(selected)) {

                // Missing prerequisite outcome
                1 -> Snackbar.make(
                    findViewById(R.id.coordinator_layout),
                    "Error Due to missing prerequisite.",
                    Snackbar.LENGTH_SHORT
                ).show()

                // Course overload outcome
                2 -> Snackbar.make(
                    findViewById(R.id.coordinator_layout),
                    "Error due to course overload; maximum 3 courses per term.",
                    Snackbar.LENGTH_SHORT
                ).show()

                // Success outcome
                else -> {

                    // Handle course name list
                    var courseNames = ArrayList<String>()
                    for (course in selected) {
                        courseNames.add(course.courseId)
                    }

                    // Send to courses selected activity
                    val intent = Intent(this, CourseSchedule::class.java)
                    intent.putStringArrayListExtra("courseList", courseNames)
                    startActivity(intent)
                }
            }
        }
    }

    private fun handleCourses(courseList: List<Course>): Int {
        // Added abstraction to onclick listener

        // Init vars to handle conditions
        var firstTermCount = 0
        var secondTermCount = 0
        val prereqList = listOf(
            "CS161",
            "CS162",
            "Math101",
            "none"
        )

        // Check all courses
        for (course in courseList) {

            // Check for prerequisite
            if (course.prereq !in prereqList) {
                return 1
            }

            // Check courseload by term restrictions
            if (course.term == 1) {
                firstTermCount++
            } else {
                secondTermCount--
            }
            if (firstTermCount > 2 || secondTermCount > 2) {
                return 2
            }

        }
        return 0
    }
}