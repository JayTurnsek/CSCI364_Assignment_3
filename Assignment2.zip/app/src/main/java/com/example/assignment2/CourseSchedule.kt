package com.example.assignment2

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class CourseSchedule : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_schedule)

        // Get selected courses
        val courseList = intent?.extras?.getStringArrayList("courseList")

        // Add preregistered ones
        courseList!!.add("CS255")
        courseList!!.add("CS263")

        // Populate listView
        val lv: ListView = findViewById(R.id.course_list_view)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            courseList!!
        )
        lv.adapter = adapter
    }

}