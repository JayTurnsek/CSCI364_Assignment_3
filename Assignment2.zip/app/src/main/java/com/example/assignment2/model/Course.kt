package com.example.assignment2.model

import java.io.Serializable

// Used to store course data
data class Course(
    val courseId: String,
    val courseName: String,
    val term: Int,
    val prereq: String
)