package com.example.assignment2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val courseListButton : Button = findViewById(R.id.course_list_button)
        courseListButton.setOnClickListener {
            val intent = Intent(this, CourseList::class.java)
            startActivity(intent)
        }
    }


}