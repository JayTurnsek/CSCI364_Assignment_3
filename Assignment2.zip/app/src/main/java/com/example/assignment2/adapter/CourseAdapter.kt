package com.example.assignment2.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment2.R
import com.example.assignment2.model.Course

class CourseAdapter(
    private val context: Context,
    private val dataset: List<Course>,
    private var selectedCourses: ArrayList<Course>
) :
    RecyclerView.Adapter<CourseAdapter.ItemViewHolder>() {
    class ItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        val codeText: TextView = view.findViewById(R.id.course_id)
        val titleText: TextView = view.findViewById(R.id.course_title)
        val termText: TextView = view.findViewById(R.id.course_term)
        val addCheck: CheckBox = view.findViewById(R.id.checkBox)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.course_item, parent, false)
        return ItemViewHolder(adapterLayout)

    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.codeText.text = item.courseId
        holder.titleText.text = item.courseName
        holder.termText.text = "Term: ${item.term}"

        // Handles data of which checkboxes selected
        holder.addCheck.setOnClickListener {
            if (holder.addCheck.isChecked) {
                selectedCourses.add(item)
            } else {
                selectedCourses.remove(item)
            }
        }


    }

    override fun getItemCount(): Int {
        return dataset.size
    }

    fun getSelectedCourses(): List<Course> {
        return selectedCourses
    }
}