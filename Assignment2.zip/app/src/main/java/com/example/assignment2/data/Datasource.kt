package com.example.assignment2.data

import com.example.assignment2.model.Course

class Datasource {
    fun loadData(): List<Course> {
        val courseIds = listOf(
            "CS128",
            "CS161",
            "CS162",
            "CS215",
            "CS225",
            "CS223",
            "CS275",
            "CS277",
            "CS340",
            "CS356",
            "CS364",
            "CS368",
            "CS375"
        )

        val courseTitles = listOf(
            "Introduction to Coding",
            "Introduction to Programming",
            "Programming and Data Structures",
            "Social Issues",
            "Health Analytics",
            "Data Science",
            "Database Management Systems",
            "Discrete Structures",
            "Evolutionary Computation",
            "Theory of Computing",
            "Mobile App Development",
            "Data Communications and Networking",
            "Operating Systems"
        )

        val terms = listOf(
            2, 1, 2, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1
        )

        val prereqs = listOf(
            "none",
            "none",
            "CS161",
            "none",
            "CS161",
            "CS161",
            "CS162",
            "Math101",
            "none",
            "CS277",
            "CS162",
            "CS255",
            "CS255"
        )

        var courseListData = mutableListOf<Course>()
        var stop = courseIds.size - 1
        for (i in 0..stop) {
            courseListData.add(
                Course(
                    courseIds[i],
                    courseTitles[i],
                    terms[i],
                    prereqs[i]
                )
            )
        }

        return courseListData
    }
}